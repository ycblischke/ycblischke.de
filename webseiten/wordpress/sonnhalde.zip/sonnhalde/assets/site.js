
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const eur=n=>n.toLocaleString('de-DE',{maximumFractionDigits:0})+' €';
const r50=n=>Math.round(n/50)*50;
const dez=(n,d=1)=>n.toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d});

/* ── Navigation, Maßband ── */
const nav=$('#nav');
$('#burger').onclick=()=>{const o=nav.classList.toggle('open');$('#burger').setAttribute('aria-expanded',o)};
$$('#links a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));
function onScroll(){const h=document.documentElement,p=h.scrollTop/(h.scrollHeight-h.clientHeight);
  $('#tapeFill').style.width=(p*100)+'%';nav.classList.toggle('solid',h.scrollTop>30)}
let tk=false;addEventListener('scroll',()=>{if(!tk){tk=true;requestAnimationFrame(()=>{onScroll();tk=false})}},{passive:true});onScroll();

/* ── Inhalte aus dem Demo-Admin (localStorage, nur für diesen Besucher sichtbar) ── */
const EDIT=null; // Demo-Änderungen gelten 1 Stunde
const escH=t=>String(t).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmtH=h=>Number.isInteger(h)?String(h):Math.floor(h)+':'+String(Math.round((h%1)*60)).padStart(2,'0');
if(EDIT){
  if(EDIT.news){$('#newsT').textContent=EDIT.news;$('#news').hidden=false}
  if(EDIT.h1a||EDIT.h1b){const b=(EDIT.h1b||'').trim().split(' '),last=b.pop()||'';
    $('#heroH').innerHTML=`<span class="ln"><span>${escH(EDIT.h1a||'')}</span></span><span class="ln"><span>${escH(b.join(' '))}${b.length?' ':''}<em>${escH(last)}</em></span></span>`
    const L=Math.max((EDIT.h1a||'').length,(EDIT.h1b||'').length);if(L>9)$('#heroH').style.fontSize=L>14?'clamp(2.3rem,5.2vw,4.4rem)':'clamp(2.7rem,6.6vw,5.6rem)'}
  if(EDIT.lead)$('#heroLead').textContent=EDIT.lead;
  $('#demo').classList.add('mine');
  $('#demo').firstElementChild.innerHTML='✎ Ihre Änderungen<span class="long"> – nur für Sie sichtbar</span>';
  $('#demo .edit').textContent='✎ Bearbeiten';
}

/* ── Öffnungszeiten & nächster Aufmaß-Termin ── */
const HOURS=(EDIT&&EDIT.hours)||[null,[7,17],[7,17],[7,17],[7,17],[7,15],[9,12]]; // So..Sa
const DAYS=['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'];
const now=new Date(),wd=now.getDay(),hr=now.getHours()+now.getMinutes()/60;
const open=HOURS[wd]&&hr>=HOURS[wd][0]&&hr<HOURS[wd][1];
function nextSlots(n){const out=[];const d=new Date();d.setDate(d.getDate()+2);
  while(out.length<n){if(d.getDay()>0&&d.getDay()<6)out.push(new Date(d));d.setDate(d.getDate()+1)}return out}
const fmtD=d=>d.toLocaleDateString('de-DE',{weekday:'short',day:'numeric',month:'numeric'});
$('#badgeT').textContent=open?`Werkstatt geöffnet bis ${fmtH(HOURS[wd][1])} Uhr`:'Werkstatt gerade geschlossen';
if(!open)$('#badge').classList.add('closed');
$('#badgeS').textContent='Nächster freier Aufmaß-Termin: '+fmtD(nextSlots(1)[0]);
$('#hours').innerHTML=[1,2,3,4,5,6,0].map(i=>`<li class="${i===wd?'today':''}"><span>${DAYS[i]}${i===wd?' · heute':''}</span><span>${HOURS[i]?fmtH(HOURS[i][0])+' – '+fmtH(HOURS[i][1])+' Uhr':'geschlossen'}${i===6?' (Ausstellung)':''}</span></li>`).join('');

/* ── Laufband ── */
const BAND=['Parkett','Massivholzküchen','Einbauschränke','Treppen','Dielen aufarbeiten','Dachschrägen','Holz aus dem Schwarzwald','Festpreis nach Aufmaß'];
$('#band').innerHTML=[...BAND,...BAND].map(t=>`<span>${t}</span>`).join('');
/* Zollstock als Hintergrund: Skala oben und unten, Gelenke alle 20 cm */
(function(){const b=$('.band'),H=b.offsetHeight||80,W=3600,cm=16;let g='';
  for(let i=0;i*cm/2<=W;i++){const x=i*cm/2,c=i/2,l=i%10===0?15:i%2===0?9:5;
    g+=`<path d="M${x} 0v${l}M${x} ${H}v-${l}"/>`;
    if(i%10===0&&i)g+=`<text x="${x+3}" y="25">${c}</text>`;
    if(i%40===0&&i)g+=`</g><path d="M${x} 0V${H}" stroke="rgba(0,0,0,.28)" stroke-width="1.5"/><circle cx="${x}" cy="${H/2}" r="3.2" fill="#B8923A" stroke="rgba(0,0,0,.35)"/><g stroke="#1D1B18" stroke-opacity=".62" stroke-width="1">`}
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}"><g stroke="#1D1B18" stroke-opacity=".62" stroke-width="1">${g}</g><style>text{font:600 10px ui-monospace,Menlo,monospace;fill:#1D1B18;fill-opacity:.55;stroke:none}</style></svg>`;
  b.style.backgroundImage=`url("data:image/svg+xml,${encodeURIComponent(svg)}")`})();

/* ── Zähler & Reveal ── */
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.12});
$$('.reveal').forEach(el=>io.observe(el));
const cio=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;cio.unobserve(e.target);
  const el=e.target,end=+el.dataset.count,suf=el.dataset.suffix||'',t0=performance.now();
  (function f(t){const k=Math.min(1,(t-t0)/1700),v=Math.round(end*(1-Math.pow(1-k,4)));el.textContent=v.toLocaleString('de-DE')+suf;if(k<1)requestAnimationFrame(f)})(t0)}),{threshold:.5});
$$('[data-count]').forEach(el=>cio.observe(el));

/* ── Leistungen: schwebendes Bild + Sprung in den Rechner ── */
const fl=$('#float');
$$('#svc button').forEach(b=>{const im=new Image();im.src=b.dataset.img;im.alt='';fl.appendChild(im);b._im=im;
  b.addEventListener('mouseenter',()=>{fl.classList.add('on');$$('#float img').forEach(x=>x.classList.toggle('on',x===im))});
  b.addEventListener('mouseleave',()=>fl.classList.remove('on'));
  b.addEventListener('click',()=>{setTab(b.dataset.tab);$('#rechner').scrollIntoView({behavior:'smooth'})})});
addEventListener('mousemove',e=>{
  /* Bild bleibt im Textbereich: nie über den Pfeil-Knöpfen rechts */
  const L=$('#svc').getBoundingClientRect().left,R=$('#svc .go').getBoundingClientRect().left-24,hw=fl.offsetWidth/2;
  fl.style.left=Math.max(L+hw,Math.min(R-hw,e.clientX))+'px';fl.style.top=e.clientY+'px'},{passive:true});

/* ── Vorher/Nachher ── */
const BA=[['fischgraet','Fischgrät'],['flur','Flur'],['dielen','Dielen']];
const cmp=$('#cmp'),cr=$('#cmpR');
const setP=v=>{cmp.style.setProperty('--p',v+'%');cr.value=v};
let peekId=0,drag=false;
cr.addEventListener('input',()=>{peekId++;setP(cr.value)});
const fromX=x=>{const r=cmp.getBoundingClientRect();setP(Math.round(Math.max(0,Math.min(100,(x-r.left)/r.width*100))*10)/10)};
cmp.addEventListener('pointerdown',e=>{peekId++;drag=true;cmp.setPointerCapture(e.pointerId);fromX(e.clientX)});
cmp.addEventListener('pointermove',e=>{if(drag)fromX(e.clientX)});
['pointerup','pointercancel'].forEach(n=>cmp.addEventListener(n,()=>drag=false));
$$('#baTabs .ba-tab').forEach(t=>t.onclick=()=>{$$('#baTabs .ba-tab').forEach(x=>x.classList.toggle('on',x===t));
  const [k]=BA[t.dataset.i];$('#cmpA').src=`${SH.img}${k}-nachher.webp`;$('#cmpB').src=`${SH.img}${k}-vorher.webp`;peek()});
BA.forEach(([k])=>{new Image().src=`${SH.img}${k}-vorher.webp`;new Image().src=`${SH.img}${k}-nachher.webp`});
function peek(){const seq=[[50,0],[78,500],[22,1100],[50,1700]];let i=0;const id=++peekId;
  const t0=performance.now();(function f(t){if(id!==peekId)return;const el=t-t0;while(i<seq.length-1&&el>seq[i+1][1])i++;
    if(i>=seq.length-1){setP(50);return}const [a,ta]=seq[i],[b,tb]=seq[i+1],k=(el-ta)/(tb-ta),e=k<.5?2*k*k:1-Math.pow(-2*k+2,2)/2;
    setP(a+(b-a)*e);requestAnimationFrame(f)})(t0)}
new IntersectionObserver((es,o)=>{if(es[0].isIntersecting){o.disconnect();setTimeout(peek,400)}},{threshold:.6}).observe(cmp);

/* ── Rechner ── */
const S={tab:'parkett',muster:'diele',holz:'eiche',zustand:'mittel',ober:'oel',form:'l',front:'lack',platte:'holz',mfront:'lack',slot:null};
$$('.chips[data-g]').forEach(g=>g.addEventListener('click',e=>{const c=e.target.closest('.chip');if(!c)return;
  $$(`.chips[data-g="${g.dataset.g}"] .chip`).forEach(x=>x.classList.toggle('on',x===c));S[g.dataset.g]=c.dataset.v;calc()}));
$$('.cform input').forEach(i=>i.addEventListener('input',calc));
function setTab(t){S.tab=t;$$('.ctab').forEach(x=>x.classList.toggle('on',x.dataset.t===t));
  $$('.cpane').forEach(p=>p.classList.toggle('on',p.dataset.p===t));$('#calcBox').classList.remove('asking');calc()}
$$('.ctab').forEach(b=>b.onclick=()=>setTab(b.dataset.t));
const val=id=>+$('#'+id).value, on=id=>$('#'+id).checked;
function fillTrack(i){const k=(i.value-i.min)/(i.max-i.min)*100;i.style.setProperty('--f',k+'%')}

const WOOD={eiche:['Eiche',[201,160,106],1],esche:['Esche',[226,205,166],.95],raeucher:['Räuchereiche',[104,74,50],1.15],nuss:['Nussbaum',[122,83,56],1.35]};
const MUSTER={diele:['Landhausdiele',75,110],schiff:['Schiffsboden',65,95],fisch:['Fischgrät',115,165],wuerfel:['Würfel',95,135]};
let last=null;
function calc(){
  $$('.cform input[type=range]').forEach(fillTrack);
  let lo=0,hi=0,rows=[],title='',sumRows=[];
  const add=(name,a,b,dim)=>{lo+=a;hi+=b;rows.push([name,a,b,dim])};
  if(S.tab==='parkett'){
    const L=val('pL'),B=val('pB'),A=L*B,U=2*(L+B);
    $('#pLo').textContent=dez(L)+' m';$('#pBo').textContent=dez(B)+' m';$('#pUmf').textContent=`Umfang ca. ${Math.round(U)} m`;
    const [mn,a,b]=MUSTER[S.muster],[wn,,f]=WOOD[S.holz];
    add(`${mn}, ${wn} · ${dez(A)} m²`,A*a*f,A*b*f);
    if(on('pAlt'))add('Alten Belag entfernen & entsorgen',A*12,A*18);
    if(on('pSock'))add(`Sockelleisten · ${Math.round(U)} m`,U*14,U*21);
    if(on('pAus'))add('Untergrund ausgleichen',A*15,A*25);
    add('Anfahrt & Baustellenschutz',90,160,1);
    title=`${mn} in ${wn}, ${dez(A)} m²`;sumRows=[['Leistung','Parkett verlegen'],['Raum',`${dez(L)} × ${dez(B)} m = ${dez(A)} m²`],['Muster',mn],['Holz',wn]];
    drawFloor(L,B);$('#vizCap').textContent=`Draufsicht · ${dez(L)} × ${dez(B)} m`;
  }else if(S.tab==='schleifen'){
    const A=val('sA');$('#sAo').textContent=A+' m²';
    const z={leicht:['leichte Kratzer',26,34],mittel:['abgelaufen',34,44],stark:['tiefe Schäden',44,58]}[S.zustand];
    const o={oel:['Naturöl',0,0],lack:['Lack matt',3,6],weiss:['weiß geölt',4,7]}[S.ober];
    add(`Schleifen (${z[0]}) · ${A} m²`,A*z[1],A*z[2]);add(`Oberfläche: ${o[0]}`,A*(8+o[1]),A*(11+o[2]));
    if(on('sFug'))add('Fugen kitten',A*6,A*9);if(on('sMoe'))add('Möbel aus- und einräumen',180,320);
    add('Anfahrt & Staubschutz',90,160,1);
    title=`Boden aufarbeiten, ${A} m²`;sumRows=[['Leistung','Boden schleifen & versiegeln'],['Fläche',A+' m²'],['Zustand',z[0]],['Oberfläche',o[0]]];
    drawSand(A);$('#vizCap').textContent=`${A} m² · ca. ${A<35?2:A<80?3:4} Tage`;
  }else if(S.tab==='kueche'){
    const L=val('kL');$('#kLo').textContent=dez(L)+' lfm';
    const fr={lack:['Lack matt',1500,2100],furnier:['Eiche furniert',2000,2700],massiv:['Massivholz',2700,3500]}[S.front];
    const pl={hpl:['Schichtstoff',110,170],holz:['Massivholz',330,480],keramik:['Keramik',650,950]}[S.platte];
    const fo={zeile:['Zeile',0,0,0],l:['L-Form',1,0,0],u:['U-Form',2,0,0],insel:['mit Insel',1,1,0]}[S.form];
    add(`Korpusse & Fronten (${fr[0]}) · ${dez(L)} lfm`,L*fr[1],L*fr[2]);
    add(`Arbeitsplatte ${pl[0]}`,L*.75*pl[1],L*.75*pl[2]);
    if(fo[1])add(`Eckverbindung${fo[1]>1?'en':''}`,fo[1]*450,fo[1]*700);
    if(fo[2])add('Kochinsel mit Arbeitsplatte',3800,5600);
    if(on('kGer'))add('Elektrogeräte (Markengeräte)',3200,6500);
    add('Lieferung, Montage, Anschlüsse',900,1400,1);
    title=`Küche ${fo[0]}, ${fr[0]}`;sumRows=[['Leistung','Küche nach Maß'],['Form',fo[0]],['Länge',dez(L)+' lfm'],['Fronten',fr[0]],['Arbeitsplatte',pl[0]],['Geräte',on('kGer')?'mit liefern':'eigene/später']];
    drawKitchen(S.form,L);$('#vizCap').textContent=`Draufsicht · ${fo[0]}`;
  }else{
    const B=val('mB'),H=val('mH'),A=B*H;$('#mBo').textContent=dez(B)+' m';$('#mHo').textContent=dez(H,2)+' m';
    const fr={lack:['Lack weiß matt',620,820],furnier:['Eiche furniert',820,1080],massiv:['Massivholz',1080,1380]}[S.mfront];
    let f=on('mSchr')?1.18:1;
    add(`Schrank ${fr[0]} · ${dez(A)} m² Front`,A*fr[1]*f,A*fr[2]*f);
    if(on('mSchr'))rows[0][0]+=' (Schräge)';
    if(on('mSch'))add('Schubladen & Auszüge',Math.ceil(B/0.6)*160,Math.ceil(B/0.6)*240);
    if(on('mLed'))add('LED-Beleuchtung mit Sensor',260,420);
    add('Lieferung & Montage',350,600,1);
    title=`Einbauschrank ${dez(B)} × ${dez(H,2)} m`;sumRows=[['Leistung','Einbauschrank nach Maß'],['Maße',`${dez(B)} × ${dez(H,2)} m`],['Fronten',fr[0]],['Dachschräge',on('mSchr')?'ja':'nein']];
    drawWardrobe(B,H);$('#vizCap').textContent=`Ansicht · ${Math.max(1,Math.round(B/0.6))} Türen`;
  }
  lo=r50(lo);hi=r50(hi);
  animPrice(lo,hi);
  $('#brk').innerHTML=rows.map(([n,a,b])=>`<li><span>${n}</span><span>${eur(r50(a))} – ${eur(r50(b))}</span></li>`).join('');
  last={title,lo,hi,sumRows};
}
let pa={lo:0,hi:0},praf;
function animPrice(lo,hi){cancelAnimationFrame(praf);const f0={...pa},t0=performance.now();
  (function f(t){const k=Math.min(1,(t-t0)/450),e=1-Math.pow(1-k,3);pa={lo:f0.lo+(lo-f0.lo)*e,hi:f0.hi+(hi-f0.hi)*e};
    $('#pr').textContent=`${eur(r50(pa.lo))} – ${eur(r50(pa.hi))}`;if(k<1)praf=requestAnimationFrame(f)})(t0)}

/* Zeichnungen */
const NS='http://www.w3.org/2000/svg';
function rnd(seed){return()=>{seed=(seed*16807)%2147483647;return(seed-1)/2147483646}}
function shade([r,g,b],j){return`rgb(${Math.max(0,Math.min(255,r+j))},${Math.max(0,Math.min(255,g+j*.85))},${Math.max(0,Math.min(255,b+j*.7))})`}
function drawFloor(L,B){
  const svg=$('#vizSvg'),W=400,H=300,pad=28,sc=Math.min((W-2*pad)/L,(H-2*pad)/B),rw=L*sc,rh=B*sc,x0=(W-rw)/2,y0=(H-rh)/2;
  const col=WOOD[S.holz][1],R=rnd(7),cm=sc/100;let s='';
  const bw=Math.max(5,(S.muster==='diele'?19:S.muster==='schiff'?14:9)*cm*1.6);
  if(S.muster==='diele'||S.muster==='schiff'){
    const len=(S.muster==='diele'?220:110)*cm*1.6;let row=0;
    for(let y=0;y<rh+bw;y+=bw,row++){let x=-(S.muster==='schiff'?(row%3)*len/3:R()*len);
      while(x<rw){const l=S.muster==='diele'?len*(.6+R()*.4):len;s+=`<rect x="${x0+x}" y="${y0+y}" width="${l}" height="${bw}" fill="${shade(col,(R()-.5)*34)}" stroke="rgba(0,0,0,.18)" stroke-width=".6"/>`;x+=l}}
  }else if(S.muster==='fisch'){
    const w=bw,l=w*5,cx=x0+rw/2,cy=y0+rh/2,n=Math.ceil((rw+rh)/w)+12;let g='';
    for(let m=-Math.ceil(n/5)-4;m<=Math.ceil(n/5)+4;m++)for(let k=-n;k<=n;k++){const ox=k*w-m*l,oy=k*w+m*l;
      if(Math.abs(ox-oy)>rw+rh+2*l&&0)continue;
      g+=`<rect x="${ox}" y="${oy}" width="${l}" height="${w}" fill="${shade(col,(R()-.5)*34)}" stroke="rgba(0,0,0,.2)" stroke-width=".6"/>`+
         `<rect x="${ox}" y="${oy+w}" width="${w}" height="${l}" fill="${shade(col,(R()-.5)*34)}" stroke="rgba(0,0,0,.2)" stroke-width=".6"/>`}
    s+=`<g transform="translate(${cx} ${cy}) rotate(-45)">${g}</g>`;
  }else{
    const t=bw*3;for(let y=0,j=0;y<rh;y+=t,j++)for(let x=0,i=0;x<rw;x+=t,i++){const hz=(i+j)%2;
      for(let q=0;q<3;q++){s+=hz?`<rect x="${x0+x}" y="${y0+y+q*bw}" width="${t}" height="${bw}" fill="${shade(col,(R()-.5)*34)}" stroke="rgba(0,0,0,.2)" stroke-width=".6"/>`
        :`<rect x="${x0+x+q*bw}" y="${y0+y}" width="${bw}" height="${t}" fill="${shade(col,(R()-.5)*34)}" stroke="rgba(0,0,0,.2)" stroke-width=".6"/>`}}
  }
  svg.innerHTML=`<defs><clipPath id="room"><rect x="${x0}" y="${y0}" width="${rw}" height="${rh}"/></clipPath></defs>
  <g clip-path="url(#room)">${s}</g><rect x="${x0}" y="${y0}" width="${rw}" height="${rh}" fill="none" stroke="#1D1B18" stroke-width="4"/>
  ${on('pSock')?`<rect x="${x0+3}" y="${y0+3}" width="${rw-6}" height="${rh-6}" fill="none" stroke="${shade(col,-25)}" stroke-width="3"/>`:''}
  <g font-family="ui-monospace,Menlo,monospace" font-size="10" fill="#8A8277" text-anchor="middle">
  <line x1="${x0}" y1="${y0-12}" x2="${x0+rw}" y2="${y0-12}" stroke="#8A8277"/><text x="${x0+rw/2}" y="${y0-16}">${dez(L)} m</text>
  <line x1="${x0-12}" y1="${y0}" x2="${x0-12}" y2="${y0+rh}" stroke="#8A8277"/><text x="${x0-16}" y="${y0+rh/2}" transform="rotate(-90 ${x0-16} ${y0+rh/2})">${dez(B)} m</text></g>`;
}
function drawSand(A){
  const svg=$('#vizSvg'),z=S.zustand,o=S.ober;const old={leicht:[150,112,70],mittel:[128,100,72],stark:[110,80,52]}[z];
  const nw={oel:[205,160,105],lack:[214,176,124],weiss:[232,218,196]}[o];const R=rnd(3);let a='',b='';
  for(let y=30;y<270;y+=14)for(let x=20,i=0;x<380;i++){const l=60+R()*70;a+=`<rect x="${x}" y="${y}" width="${l}" height="14" fill="${shade(old,(R()-.5)*30)}" stroke="rgba(0,0,0,.25)" stroke-width=".6"/>`;
    b+=`<rect x="${x}" y="${y}" width="${l}" height="14" fill="${shade(nw,(R()-.5)*22)}" stroke="rgba(0,0,0,.15)" stroke-width=".6"/>`;x+=l}
  let sc='';for(let i=0;i<({leicht:14,mittel:30,stark:55}[z]);i++){const x=30+R()*330,y=40+R()*220;sc+=`<line x1="${x}" y1="${y}" x2="${x+10+R()*30}" y2="${y+(R()-.5)*14}" stroke="rgba(40,25,15,.5)" stroke-width="${R()*1.4+.4}"/>`}
  svg.innerHTML=`<defs><clipPath id="cl"><rect x="20" y="30" width="180" height="240"/></clipPath><clipPath id="cr"><rect x="200" y="30" width="180" height="240"/></clipPath></defs>
  <g clip-path="url(#cl)">${a}${sc}</g><g clip-path="url(#cr)">${b}</g>
  <line x1="200" y1="22" x2="200" y2="278" stroke="#1D1B18" stroke-width="2"/>
  <g font-family="ui-monospace,Menlo,monospace" font-size="10" fill="#8A8277"><text x="24" y="20">VORHER</text><text x="376" y="20" text-anchor="end">NACHHER</text></g>`;
}
function drawKitchen(f,L){
  const svg=$('#vizSvg'),d=34,c=S.front==='lack'?'#ECE7DE':S.front==='furnier'?'#C9A06A':'#A87545',top=S.platte==='hpl'?'#BDB6AA':S.platte==='holz'?'#B98A55':'#5D5A55';
  const u=Math.min(58,290/L);let s='';const x0=50,y0=40,len=Math.min(300,L*u);
  const run=(x,y,w,h)=>{s+=`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${top}" stroke="#1D1B18" stroke-width="1.5"/>`;
    const n=Math.max(1,Math.round((w>h?w:h)/26));for(let i=1;i<n;i++)s+=w>h?`<line x1="${x+i*w/n}" y1="${y+h-6}" x2="${x+i*w/n}" y2="${y+h}" stroke="#1D1B18" stroke-width=".8"/>`:`<line x1="${x+w-6}" y1="${y+i*h/n}" x2="${x+w}" y2="${y+i*h/n}" stroke="#1D1B18" stroke-width=".8"/>`;
    s+=w>h?`<rect x="${x}" y="${y+h-5}" width="${w}" height="5" fill="${c}" opacity=".95"/>`:`<rect x="${x+w-5}" y="${y}" width="5" height="${h}" fill="${c}" opacity=".95"/>`};
  if(f==='zeile'){run(x0,y0+20,len,d)}
  else if(f==='l'||f==='insel'){const a=len*.62,b=Math.max(d+30,len*.38+d);run(x0,y0,a,d);run(x0,y0+d,d,b);
    if(f==='insel')s+=`<rect x="${x0+90}" y="${y0+110}" width="150" height="62" rx="3" fill="${top}" stroke="#1D1B18" stroke-width="1.5"/><rect x="${x0+90}" y="${y0+110}" width="150" height="6" fill="${c}"/>`}
  else{const a=len*.44,b=len*.28+d;run(x0,y0,a,d);run(x0,y0+d,d,b);run(x0+a-d,y0+d,d,b)}
  s+=`<circle cx="${x0+60}" cy="${y0+17}" r="8" fill="none" stroke="#1D1B18" stroke-width="1.2"/><circle cx="${x0+80}" cy="${y0+17}" r="8" fill="none" stroke="#1D1B18" stroke-width="1.2"/>`;
  svg.innerHTML=`<rect x="20" y="15" width="360" height="270" fill="none" stroke="#D8D0C2" stroke-dasharray="4 4"/>${s}<text x="380" y="280" text-anchor="end" font-family="ui-monospace,Menlo,monospace" font-size="10" fill="#8A8277">${dez(L)} lfm</text>`;
}
function drawWardrobe(B,H){
  const svg=$('#vizSvg'),sc=Math.min(320/B,230/H),w=B*sc,h=H*sc,x0=(400-w)/2,y0=275-h,n=Math.max(1,Math.round(B/0.6)),c=S.mfront==='lack'?'#F4F1EA':S.mfront==='furnier'?'#C9A06A':'#A87545';
  const sl=on('mSchr');let p=sl?`M${x0} ${y0+h} V${y0} H${x0+w*.45} L${x0+w} ${y0+h*.55} V${y0+h} Z`:`M${x0} ${y0+h} V${y0} H${x0+w} V${y0+h} Z`;
  let doors='';for(let i=1;i<n;i++)doors+=`<line x1="${x0+i*w/n}" y1="${y0}" x2="${x0+i*w/n}" y2="${y0+h}" stroke="#1D1B18" stroke-width="1.2"/>`;
  for(let i=0;i<n;i++){const cx=x0+(i+.5)*w/n+(i%2?-1:1)*(w/n*.38);doors+=`<rect x="${cx-1.5}" y="${y0+h*.62}" width="3" height="${Math.min(30,h*.12)}" rx="1.5" fill="#1D1B18" opacity=".6"/>`}
  const led=on('mLed')?`<rect x="${x0}" y="${y0-4}" width="${w}" height="3" fill="#FFD27A" opacity=".9"/>`:'';
  svg.innerHTML=`<defs><clipPath id="wc"><path d="${p}"/></clipPath></defs>
  ${sl?`<path d="M${x0+w*.45-20} ${y0-14} L${x0+w+20} ${y0+h*.55+28}" stroke="#D8D0C2" stroke-width="10"/>`:''}
  <path d="${p}" fill="${c}" stroke="#1D1B18" stroke-width="2"/><g clip-path="url(#wc)">${doors}</g>${led}
  <line x1="20" y1="276" x2="380" y2="276" stroke="#1D1B18" stroke-width="1.5"/>
  <g font-family="ui-monospace,Menlo,monospace" font-size="10" fill="#8A8277" text-anchor="middle"><text x="${x0+w/2}" y="292">${dez(B)} m</text><text x="${x0-12}" y="${y0+h/2}" transform="rotate(-90 ${x0-12} ${y0+h/2})">${dez(H,2)} m</text></g>`;
}

/* Anfrage */
const slots=nextSlots(4);
$('#slots').innerHTML=slots.map((d,i)=>`<button type="button" class="chip${i===0?' on':''}" data-v="${fmtD(d)}">${fmtD(d)}<small style="color:var(--mute)">${i%2?'14 Uhr':'9 Uhr'}</small></button>`).join('');
S.slot=fmtD(slots[0])+' 9 Uhr';
$('#slots').addEventListener('click',e=>{const c=e.target.closest('.chip');if(c)S.slot=c.textContent.replace(/(\d+ Uhr)$/,' $1')});
$('#toAsk').onclick=()=>{calc();$('#sum').innerHTML=`<h4>${last.title}</h4><p style="font-family:Bricolage;font-size:1.6rem;font-weight:700;letter-spacing:-.02em">${eur(last.lo)} – ${eur(last.hi)}</p><p style="color:var(--mute);font-size:.8rem;margin-bottom:.8rem">Preisrahmen aus dem Rechner</p>`+
  `<table style="width:100%;font-size:.86rem;border-collapse:collapse">${last.sumRows.map(([a,b])=>`<tr><td style="color:var(--mute);padding:.3rem 0">${a}</td><td style="text-align:right">${b}</td></tr>`).join('')}</table>
  <p style="margin-top:1rem;font-size:.82rem;color:var(--ink2)">Nach dem Aufmaß bekommen Sie einen <b>Festpreis</b>. Das Aufmaß ist kostenlos.</p>`;
  $('#calcBox').classList.add('asking');$('#calcBox').scrollIntoView({behavior:'smooth',block:'start'})};
$('#back').onclick=()=>$('#calcBox').classList.remove('asking');
const files=[];const drop=$('#drop');
['dragenter','dragover'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add('over')}));
['dragleave','drop'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove('over')}));
drop.addEventListener('drop',e=>addFiles(e.dataTransfer.files));$('#files').onchange=e=>addFiles(e.target.files);
function addFiles(fs){[...fs].filter(f=>f.type.startsWith('image/')).slice(0,6-files.length).forEach(f=>{files.push(f);const u=URL.createObjectURL(f);$('#thumbs').insertAdjacentHTML('beforeend',`<img src="${u}" alt="">`)})}
$('#askForm').onsubmit=e=>{e.preventDefault();const f=new FormData(e.target);const nm=(f.get('name')||'').trim();
  if(!nm){e.target.name.focus();e.target.name.style.borderColor='#C0392B';return}
  $('#mailTop').innerHTML=`<b>Von:</b> Website-Formular &lt;anfrage@holzwerkstatt-sonnhalde.de&gt;<br><b>Betreff:</b> Neue Anfrage: ${last.title}<br><b>Eingang:</b> ${new Date().toLocaleString('de-DE',{dateStyle:'medium',timeStyle:'short'})}`;
  const esc=s=>String(s||'–').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
  $('#mailBody').innerHTML=`<p>Neue Anfrage über den Angebotsrechner:</p><table>
   <tr><td>Kunde</td><td><b>${esc(nm)}</b></td></tr><tr><td>Telefon</td><td>${esc(f.get('tel'))}</td></tr><tr><td>E-Mail</td><td>${esc(f.get('mail'))}</td></tr><tr><td>Ort</td><td>${esc(f.get('ort'))}</td></tr>
   ${last.sumRows.map(([a,b])=>`<tr><td>${a}</td><td>${b}</td></tr>`).join('')}
   <tr><td>Preisrahmen gezeigt</td><td><b>${eur(last.lo)} – ${eur(last.hi)}</b></td></tr><tr><td>Wunschtermin Aufmaß</td><td>${esc(S.slot)}</td></tr>
   <tr><td>Fotos</td><td>${files.length?files.length+' Bild(er) im Anhang':'keine'}</td></tr><tr><td>Nachricht</td><td>${esc(f.get('msg'))}</td></tr></table>
   ${files.length?`<div class="thumbs">${$$('#thumbs img').map(i=>`<img src="${i.src}" alt="">`).join('')}</div>`:''}`;
  $('#modal').classList.add('on')};
$('#mailX').onclick=()=>$('#modal').classList.remove('on');
$('#modal').onclick=e=>{if(e.target.id==='modal')$('#modal').classList.remove('on')};
function demoMsg(w){alert(`Demo: Hier würde ${w==='Telefon'?'direkt der Anruf starten':'WhatsApp mit einer vorbereiteten Nachricht öffnen'}.`);return false}
setTab('parkett');


/* ── Team & Terminbuchung ── */
const TEAM=['Sabine Wehrle','Martin Gersbach'];
const backTxt=(()=>{if(HOURS[wd]&&hr<HOURS[wd][0])return 'ab '+fmtH(HOURS[wd][0])+' Uhr wieder da';
  for(let k=1;k<7;k++){const d=(wd+k)%7;if(HOURS[d])return k===1?'ab morgen wieder da':'ab '+DAYS[d]+' wieder da'}})();
$$('[data-on]').forEach(b=>{if(!open){b.classList.add('off');b.querySelector('em').textContent=backTxt}});
const BK={p:0,art:'Ausstellung Schopfheim',day:null,time:null};
const bkDays=nextSlots(5);
function busy(p,d,t){return ((d.getDate()*7+t*3+p*5)%5)<2} // feste Demo-Belegung
function bkRender(){
  $('#bkDay').innerHTML=bkDays.map((d,i)=>`<button type="button" data-i="${i}" class="${BK.day===i?'on':''}">${d.toLocaleDateString('de-DE',{weekday:'short'})}<small>${d.toLocaleDateString('de-DE',{day:'numeric',month:'numeric'})}</small></button>`).join('');
  const times=BK.art==='Videoberatung'?['8:30','10:00','11:30','14:00','16:00']:['8:00','10:00','13:00','15:00'];
  $('#bkTime').innerHTML=BK.day===null?'<span style="font-size:.85rem;opacity:.55">Bitte zuerst einen Tag wählen</span>':
    times.map((t,j)=>`<button type="button" data-t="${t}" ${busy(BK.p,bkDays[BK.day],j)?'disabled title="belegt"':''} class="${BK.time===t?'on':''}">${t}</button>`).join('');
  $('#bkSum').textContent=BK.day!==null&&BK.time?`✓ ${BK.art} mit ${TEAM[BK.p].split(' ')[0]} · ${fmtD(bkDays[BK.day])}, ${BK.time} Uhr`:'';
}
$('#who').onclick=e=>{const b=e.target.closest('button');if(!b)return;BK.p=+b.dataset.p;BK.time=null;$$('#who button').forEach(x=>x.classList.toggle('on',x===b));bkRender()};
$('#bkArt').onclick=e=>{const b=e.target.closest('button');if(!b)return;BK.art=b.dataset.v;BK.time=null;$$('#bkArt button').forEach(x=>x.classList.toggle('on',x===b));bkRender()};
$('#bkDay').onclick=e=>{const b=e.target.closest('button');if(!b)return;BK.day=+b.dataset.i;BK.time=null;bkRender()};
$('#bkTime').onclick=e=>{const b=e.target.closest('button');if(!b||b.disabled)return;BK.time=b.dataset.t;bkRender()};
$$('[data-book]').forEach(b=>b.onclick=()=>{$$('#who button')[+b.dataset.book].click();$('#book').scrollIntoView({behavior:'smooth',block:'start'})});
$('#bkForm').onsubmit=e=>{e.preventDefault();const f=e.target;
  if(BK.day===null||!BK.time){$('#bkSum').textContent='Bitte Tag und Uhrzeit wählen.';return}
  const nm=f.name.value.trim();if(!nm){f.name.focus();f.name.style.borderColor='#E07A5F';return}
  const esc=x=>String(x||'–').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
  $('#mailTop').innerHTML=`<b>An:</b> ${TEAM[BK.p]} &lt;${TEAM[BK.p].split(' ')[0].toLowerCase()}@holzwerkstatt-sonnhalde.de&gt;<br><b>Betreff:</b> Neuer Beratungstermin: ${fmtD(bkDays[BK.day])}, ${BK.time} Uhr<br><b>Kalender:</b> automatisch eingetragen ✓`;
  $('#mailBody').innerHTML=`<p>Neuer Termin über die Website:</p><table><tr><td>Kunde</td><td><b>${esc(nm)}</b></td></tr><tr><td>Telefon</td><td>${esc(f.tel.value)}</td></tr><tr><td>Art</td><td>${BK.art}</td></tr><tr><td>Termin</td><td><b>${bkDays[BK.day].toLocaleDateString('de-DE',{weekday:'long',day:'numeric',month:'long'})}, ${BK.time} Uhr</b></td></tr><tr><td>Berater/in</td><td>${TEAM[BK.p]}</td></tr></table><p style="color:var(--mute);font-size:.82rem">Der Kunde erhält automatisch eine Bestätigung per SMS und eine Erinnerung am Vortag.</p>`;
  $('#modal').classList.add('on')};
bkRender();

/* ── Galerie ── */
const GAL=[ /* [Spalten,Zeilen], Filter, Bild, Titel, Ort */
 [[7,3],'boden',SH.img+'fischgraet-nachher.webp','Fischgrät in Eiche','Altbau, Lörrach · 2025'],
 [[5,4],'moebel',SH.img+'regal.webp','Bücherwand raumhoch','Stadtwohnung, Riehen (CH) · 2025'],
 [[7,3],'kueche',SH.img+'kueche2.webp','Grifflose Küche mit Eichenfronten','Neubau, Steinen · 2025'],
 [[5,2],'kueche',SH.img+'induktion.webp','Einbaugeräte: Flächeninduktion','flächenbündig in Keramik · 2025'],
 [[4,3],'kueche',SH.img+'kueche3.webp','Küche mit Theke & Regalwange','Wohnung, Lörrach · 2025'],
 [[4,3],'kueche',SH.img+'kueche4.webp','Kochinsel in Steinoptik','Loft, Rheinfelden · 2024'],
 [[4,3],'moebel',SH.img+'treppe.webp','Wendeltreppe aufgearbeitet','Stadthaus, Schopfheim · 2024'],
 [[3,2],'boden',SH.img+'dielen-nachher.webp','Dielen geschliffen & geölt','Bauernhaus, Kandern · 2025'],
 [[3,2],'kueche',SH.img+'dampfgarer.webp','Einbaugeräte: Dampfgarer','auf Griffhöhe eingebaut · 2025'],
 [[3,2],'kueche',SH.img+'kueche.webp','Küche mit Lamellenwand','Neubau, Maulburg · 2024'],
 [[3,2],'boden',SH.img+'flur-nachher.webp','Flur in Fischgrät','Weil am Rhein · 2025'],
];
$('#gal').innerHTML=GAL.map(([[c,r],f,src,t,s],i)=>`<figure class="gi${c>=7?' w':''}" style="--c:${c};--r:${r}" data-f="${f}" data-i="${i}"><img src="${src}" alt="${t}" loading="lazy"><figcaption><b>${t}</b>${s}</figcaption></figure>`).join('');
$$('#filters button').forEach(b=>b.onclick=()=>{$$('#filters button').forEach(x=>x.classList.toggle('on',x===b));
  $$('#gal .gi').forEach(g=>g.classList.toggle('hide',b.dataset.f!=='alle'&&g.dataset.f!==b.dataset.f))});
const lb=$('#lb');let li=0;
const show=i=>{li=(i+GAL.length)%GAL.length;lb.querySelector('img').src=GAL[li][2];lb.querySelector('img').alt=GAL[li][3];lb.querySelector('p').textContent=GAL[li][3]+' · '+GAL[li][4]};
$('#gal').onclick=e=>{const g=e.target.closest('.gi');if(g){show(+g.dataset.i);lb.classList.add('on')}};
lb.querySelector('.x').onclick=()=>lb.classList.remove('on');lb.querySelector('.pv').onclick=()=>show(li-1);lb.querySelector('.nx').onclick=()=>show(li+1);
lb.onclick=e=>{if(e.target===lb)lb.classList.remove('on')};
addEventListener('keydown',e=>{if(e.key==='Escape'){lb.classList.remove('on');$('#modal').classList.remove('on')}
  if(lb.classList.contains('on')){if(e.key==='ArrowLeft')show(li-1);if(e.key==='ArrowRight')show(li+1)}});

/* ── Einzugsgebiet ── */
// Positionen grob nach Geografie (x,y in Kartenpixeln), km ab Schopfheim
const TOWNS=[['Schopfheim','79650',0,250,170],['Maulburg','79689',4,222,186],['Hausen i. W.','79688',6,262,140],['Steinen','79585',8,194,200],['Wehr','79664',11,312,210],['Zell im Wiesental','79669',10,282,110],
 ['Kandern','79400',17,150,108],['Lörrach','79539',15,160,232],['Rheinfelden','79618',16,250,268],['Weil am Rhein','79576',20,112,250],['Bad Säckingen','79713',21,352,262],['Todtnau','79674',24,300,52],
 ['Riehen (CH)','4125',19,142,262],['Basel (CH)','4051',23,112,286],['Müllheim','79379',33,108,40],['Freiburg','79098',48,150,6]];
const map=$('#map');const C=[250,170];
let ms=`<rect width="440" height="374" fill="#FBF8F2"/>
<path d="M0 300 C60 290 90 300 130 296 S200 285 250 300 330 295 440 292" fill="none" stroke="#B9CFD6" stroke-width="7" stroke-linecap="round"/>
<path d="M110 0 C112 60 100 140 108 240 S110 296 112 300" fill="none" stroke="#B9CFD6" stroke-width="5" stroke-linecap="round" opacity=".7"/>
<path d="M300 40 C290 90 270 130 250 170 S190 220 165 235" fill="none" stroke="#B9CFD6" stroke-width="3" opacity=".8"/>
<text x="20" y="316" font-family="Inter" font-size="10" fill="#7A9BA6" font-style="italic">Rhein</text><text x="282" y="94" font-family="Inter" font-size="10" fill="#7A9BA6" font-style="italic">Wiese</text>
<path d="M0 312 L440 306" stroke="#C9BFAF" stroke-dasharray="2 4"/><text x="430" y="326" text-anchor="end" font-family="ui-monospace,Menlo,monospace" font-size="9" fill="#8A8277">DE ↑ · CH ↓</text>`;
[[30,'0'],[60,'']].forEach(([km])=>ms+=`<circle class="ring" cx="${C[0]}" cy="${C[1]}" r="${km*4.2}"/>`);
ms+=`<text x="${C[0]-30*4.2*0.72}" y="${C[1]+30*4.2*0.75+12}" text-anchor="middle" font-family="ui-monospace,Menlo,monospace" font-size="9" fill="#C0843A">30 km · Aufmaß gratis</text>`;
TOWNS.forEach(([n,,km,x,y],i)=>ms+=`<g class="town" data-i="${i}"><circle cx="${x}" cy="${y}" r="${i?4:7}" fill="${i?'#4A453E':'#C0843A'}"/><text x="${x+8}" y="${y+4}" ${i?'':'font-weight="700"'}>${n}</text></g>`);
map.innerHTML=ms;
const ortIn=$('#ortIn'),sugg=$('#sugg');
function answer(i){const [n,,km]=TOWNS[i];$$('#map .town').forEach(t=>t.classList.toggle('on',+t.dataset.i===i));
  const ch=n.includes('(CH)');let t,s;
  if(km<=30){t=`Ja – ${n} liegt ${km?'ca. '+km+' km':'direkt'} von uns.`;s=`Aufmaß kostenlos, Anfahrt im Festpreis enthalten.${ch?' Lieferung in die Schweiz inkl. Zollpapieren – Sie zahlen keine deutsche MwSt.':''}`}
  else if(km<=50){t=`Ja – ${n} ist ca. ${km} km entfernt.`;s='Wir kommen gern. Fürs Aufmaß berechnen wir eine kleine Anfahrtspauschale von 45 €, die bei Auftrag angerechnet wird.'}
  else{t=`${n} ist leider etwas weit.`;s='Für größere Projekte machen wir eine Ausnahme – rufen Sie einfach an.'}
  $('#ans').innerHTML=`<b>${t}</b>${s}`;$('#ans').classList.add('on');ortIn.value=n;sugg.style.display='none'}
ortIn.addEventListener('input',()=>{const q=ortIn.value.trim().toLowerCase();if(!q){sugg.style.display='none';return}
  const m=TOWNS.map((t,i)=>[t,i]).filter(([t])=>t[0].toLowerCase().includes(q)||t[1].startsWith(q)).slice(0,6);
  if(!m.length){sugg.innerHTML=`<li style="cursor:default">Ort nicht in der Liste – <a href="#kontakt">einfach fragen</a></li>`;sugg.style.display='block';return}
  sugg.innerHTML=m.map(([t,i])=>`<li data-i="${i}">${t[0]}<span>${t[1]} · ${t[2]} km</span></li>`).join('');sugg.style.display='block'});
ortIn.addEventListener('keydown',e=>{if(e.key==='Enter'){const f=sugg.querySelector('li[data-i]');if(f)answer(+f.dataset.i)}});
sugg.onclick=e=>{const li=e.target.closest('li[data-i]');if(li)answer(+li.dataset.i)};
map.onclick=e=>{const t=e.target.closest('.town');if(t)answer(+t.dataset.i)};
document.addEventListener('click',e=>{if(!e.target.closest('.ort'))sugg.style.display='none'});

/* ── Demo-Pille & Bildnachweise ── */
$('#demoX').onclick=()=>$('#demo').classList.add('gone');
const CREDITS=[
 ['Fischgrät-Parkett','Pazzo4562','CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File:Oak_herringbone_wood_floor_with_two_stripe_wenge_border.jpg'],
 ['Parkett im Flur','Heritage Wood Floors Ltd','CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File:Distressed_parquet_floor.jpg'],
 ['Dielenboden','Northernveil','CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File:Parkett.jpeg'],
 ['Küche Lamellen','Shixart1985','CC BY 2.0','https://commons.wikimedia.org/wiki/File:Modern_luxury_living_room_with_kitchen_interior.jpg'],
 ['Grifflose Küche','Shixart1985','CC BY 2.0','https://commons.wikimedia.org/wiki/File:Modern_kitchen_design_featuring_minimalistic_elements,_warm_lighting,_and_high-end_appliances_in_a_contemporary_setting.jpg'],
 ['Küche mit Theke','Scarlett &amp; Rosi Interiéry','CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File:Neugraf-kuchyne-scarlett-rosi.jpg'],
 ['Kochinsel','Anna Sayapina','CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File:Dekton_Black_Kitchen,_Stone_Hood_Wrap,_Lapitec_Island.jpg'],
 ['Flächeninduktion','SCHOTT AG','CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File:Ceran_Matte_Cooktop.jpg'],
 ['Dampfgarer','BBCLCD','CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File:Combi-Steamer_SL_V-Zug.jpg'],
 ['Sabine (Porträt)','Shixart1985','CC BY 2.0','https://commons.wikimedia.org/wiki/File:Woman_smiling_while_talking_on_the_phone_by_the_window.jpg'],
 ['Martin (Porträt)','Shixart1985','CC BY 2.0','https://commons.wikimedia.org/wiki/File:Handsome_senior_bearded_man_looking_at_camera.jpg'],
 ['Werkstatt-Team 1','Shixart1985','CC BY 2.0','https://commons.wikimedia.org/wiki/File:Craftsman_shaping_wood_in_a_workshop_during_daylight_hours_with_focus_on_precision_and_detail_in_woodworking.jpg'],
 ['Werkstatt-Team 2','Shixart1985','CC BY 2.0','https://commons.wikimedia.org/wiki/File:Woodworking_process_involves_crafting_wooden_pieces_at_a_workbench.jpg'],
 ['Werkstatt-Team 3','Shixart1985','CC BY 2.0','https://commons.wikimedia.org/wiki/File:Carpenter_using_electric_sander_to_smooth_wooden_boards_in_a_workshop.jpg'],
 ['Bücherwand','Shixart1985','CC BY 2.0','https://commons.wikimedia.org/wiki/File:Library_stacks_of_books_and_bookshelf.jpg'],
 ['Treppe','Tim Evanson','CC BY-SA 2.0','https://commons.wikimedia.org/wiki/File:Gatehouse_stairs_-_Riverside_Cemetery_Cleveland_(30341496944).jpg'],
 ['Werkstatt','Jorge Royan','CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File:Paris_-_Carpenter_workshop_-_4944.jpg'],
 ['Schreiner','Wetscher GmbH','CC BY-SA 4.0','https://commons.wikimedia.org/wiki/File:Wetscher_Werkst%C3%A4tten.jpg'],
 ['Eiche','William Warby','CC BY 2.0','https://commons.wikimedia.org/wiki/File:Oak_Texture_-_5106733699_c1d5b0df29_b.jpg'],
 ['Nussbaum','Martin Lorenz','CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File:Oberfl%C3%A4che_Wohnzimmertisch.JPG'],
 ['Esche','Cyril5555','CC BY-SA 3.0','https://commons.wikimedia.org/wiki/File:Texture_chene.jpg'],
];
$('#credits').innerHTML='Personen, Namen und Zitate sind erfunden (Beispielfotos). Bildnachweise (Wikimedia Commons, verkleinert, zugeschnitten; „Vorher“-Bilder und Räuchereiche farblich bearbeitet): '+CREDITS.map(([t,a,l,u])=>`${t}: ${a}, <a href="${u}" target="_blank" rel="noopener">${l}</a>`).join(' · ')+'. Schriften: Bricolage Grotesque &amp; Inter (SIL OFL), lokal eingebunden – keine Verbindung zu Google.';
