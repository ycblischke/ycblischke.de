<?php
/**
 * Richtet die Demo ein: Startseite aus Blöcken, Hero-Bild in der Mediathek, Seiten & Einstellungen.
 * Wird einmalig vom Playground-Blueprint ausgeführt (runPHP).
 */
wp_set_current_user( 1 );
kses_remove_filters();

$dir = get_theme_file_path( 'setup/' );

// Hero-Bild in die Mediathek (damit man es im Editor austauschen kann).
$src    = get_theme_file_path( 'assets/img/hero.webp' );
$upload = wp_upload_bits( 'werkstatt-hobel.webp', null, file_get_contents( $src ) );
$att_id = wp_insert_attachment(
	array(
		'post_mime_type' => 'image/webp',
		'post_title'     => 'Hobel in der Werkstatt',
		'post_status'    => 'inherit',
	),
	$upload['file']
);
update_post_meta( $att_id, '_wp_attachment_image_alt', 'Hobel auf frischen Holzspänen in der Werkstatt' );
require_once ABSPATH . 'wp-admin/includes/image.php';
@wp_update_attachment_metadata( $att_id, @wp_generate_attachment_metadata( $att_id, $upload['file'] ) );

// Weitere Bilder in die Mediathek, damit man beim Üben etwas zum Auswählen hat.
foreach ( array( 'werkstatt', 'meister', 'kueche2', 'regal', 'treppe', 'fischgraet-nachher' ) as $n ) {
	$u = wp_upload_bits( $n . '.webp', null, file_get_contents( get_theme_file_path( "assets/img/$n.webp" ) ) );
	if ( empty( $u['error'] ) ) {
		$id = wp_insert_attachment( array( 'post_mime_type' => 'image/webp', 'post_title' => ucfirst( str_replace( '-', ' ', $n ) ), 'post_status' => 'inherit' ), $u['file'] );
		@wp_update_attachment_metadata( $id, @wp_generate_attachment_metadata( $id, $u['file'] ) );
	}
}

$content = str_replace(
	array( '{{HERO_ID}}', '{{HERO_URL}}' ),
	array( (string) $att_id, wp_get_attachment_url( $att_id ) ),
	file_get_contents( $dir . 'content.html' )
);

$front = wp_insert_post(
	array(
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_title'   => 'Startseite',
		'post_name'    => 'startseite',
		'post_content' => wp_slash( $content ),
	)
);

$impressum = wp_insert_post(
	array(
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_title'   => 'Impressum',
		'post_content' => wp_slash( "<!-- wp:paragraph -->\n<p>Holzwerkstatt Sonnhalde (frei erfunden – Demo-Seite)<br>Am Sägebach 7 · 79650 Schopfheim</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Gestaltung &amp; Umsetzung: Yves Claudio Blischke · ycblischke.de</p>\n<!-- /wp:paragraph -->" ),
	)
);

// Beispiel-Inhalte von WordPress entfernen.
foreach ( array( 1, 2, 3 ) as $old ) {
	if ( get_post( $old ) && ! in_array( $old, array( $front, $impressum, $att_id ), true ) ) {
		wp_delete_post( $old, true );
	}
}

update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', $front );
update_option( 'blogname', 'Holzwerkstatt Sonnhalde' );
update_option( 'blogdescription', 'Schreinerei & Parkett im Wiesental' );
update_option( 'permalink_structure', '/%postname%/' );
flush_rewrite_rules();
