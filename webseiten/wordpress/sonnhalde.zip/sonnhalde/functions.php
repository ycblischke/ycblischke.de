<?php
/**
 * Sonnhalde – Demo-Theme einer Schreinerei (Block-Theme).
 * Gestaltung & Umsetzung: Yves Claudio Blischke · ycblischke.de
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'editor-styles' );
	add_editor_style( array( 'assets/site.css', 'assets/editor.css' ) );
} );

add_action( 'wp_enqueue_scripts', function () {
	$v = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'sonnhalde', get_theme_file_uri( 'assets/site.css' ), array(), $v );
	wp_enqueue_script( 'sonnhalde', get_theme_file_uri( 'assets/site.js' ), array(), $v, array( 'in_footer' => true ) );
	wp_add_inline_script( 'sonnhalde', 'window.SH=' . wp_json_encode( array( 'img' => get_theme_file_uri( 'assets/img/' ) ) ) . ';', 'before' );
	// Nicht benötigte Standard-Styles von WordPress weglassen – das Theme bringt alles selbst mit.
	wp_dequeue_style( 'classic-theme-styles' );
	wp_dequeue_style( 'global-styles' ); // Abstände/Farben kommen komplett aus site.css
} );

add_action( 'wp_head', function () {
	printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( get_theme_file_uri( 'assets/fonts/bricolage.woff2' ) ) );
	echo '<meta name="theme-color" content="#F3EEE5">' . "\n";
	echo '<meta name="description" content="Demo-Webseite einer Schreinerei in WordPress: Parkett, Küchen und Möbel nach Maß. Gestaltet von ycblischke.de.">' . "\n";
}, 1 );

// Demo: nicht von Suchmaschinen erfassen lassen.
add_filter( 'wp_robots', 'wp_robots_no_robots' );

// Bilder in HTML-Blöcken: Platzhalter {{IMG}} → Bilder-Ordner des Themes.
add_filter( 'render_block_core/html', function ( $html ) {
	return str_replace( '{{IMG}}', esc_url( get_theme_file_uri( 'assets/img/' ) ), $html );
} );
add_filter( 'render_block_core/template-part', function ( $html ) {
	return str_replace( '{{IMG}}', esc_url( get_theme_file_uri( 'assets/img/' ) ), $html );
} );

// Hinweis-Leiste unten: führt Besucher direkt in den WordPress-Editor.
add_action( 'wp_footer', function () {
	$front = (int) get_option( 'page_on_front' );
	$edit  = $front ? admin_url( 'post.php?post=' . $front . '&action=edit' ) : admin_url();
	$label = is_user_logged_in() ? '✎ Im WordPress bearbeiten' : '✎ Anmelden &amp; bearbeiten';
	printf(
		'<div class="demo" id="demo"><span>✦ WordPress-Demo<span class="long"> – gebaut von Yves Claudio Blischke</span></span><a href="%s" class="edit">%s</a><a href="https://ycblischke.de/#kontakt">Auch so eine Seite?</a><button class="x" id="demoX" aria-label="Hinweis ausblenden">×</button></div>',
		esc_url( $edit ),
		$label
	);
}, 5 );
